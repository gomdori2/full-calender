import { Link } from "react-router-dom";

function App() {
  return (
    <>
      <Link to="/rc"></Link>
      <Link to="/ReactSpinner"></Link>
    </>
  );
}

export default App;
